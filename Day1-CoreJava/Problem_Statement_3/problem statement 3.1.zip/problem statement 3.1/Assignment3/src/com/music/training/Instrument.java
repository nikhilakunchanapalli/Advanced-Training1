package com.music.training;

public abstract class Instrument {
	public abstract void play();
}
